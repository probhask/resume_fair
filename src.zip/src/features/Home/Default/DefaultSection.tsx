const DefaultSection = () => {
  return (
    <div className="w-full h-full flex justify-center items-center relative bg-black overflow-hidden">
      <div className=" ">
        <img src="/logo-color.png" className="contain w-full h-full " alt="" />
      </div>
    </div>
  );
};

export default DefaultSection;
